import { _decorator, AudioSource, CCInteger, Component, Node, director, Contact2DType, Collider2D, IPhysics2DContact } from 'cc';
import { Ground } from './Ground';
import { Results } from './Results';
import { Bird } from './Bird';
import { PipePool } from './PipePool';
import { BirdAudio } from './BirdAudio';

/* 
    Game Name: The One Who Flaps
    Author: Kenneth Cherry
    Purpose: Main controller script that manages game flow, input handling, scoring, pipe generation, collision detection, and game state.
             (Sadly I couldn't fix the bug that starts the game. You have to let the bird die before you can start the game.
             I tried to fix it but I couldn't figure it out.)
    Date: September 18, 2026
*/

const { ccclass, property } = _decorator;

@ccclass('GameCtrl')
export class GameCtrl extends Component {

    @property(Ground)
    public ground: Ground = null;

    @property(Results)
    public result: Results = null;
    
    @property(Bird)
    public bird: Bird = null;

    @property(PipePool)
    public pipeQueue: PipePool = null;

    @property(BirdAudio)
    public audio: BirdAudio = null;

    @property(CCInteger)
    public speed: number = 300;

    @property(CCInteger)
    public pipeSpeed: number = 200;

    public isOver: boolean = true;

    onLoad() {
        this.initListener();
        this.result.resetScore();
        this.isOver = true;
        director.pause();

        // ⭐ Add collision listener ONCE
        const collider = this.bird.getComponent(Collider2D);
        if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
        }
    }

    initListener() {
        this.node.on(Node.EventType.TOUCH_START, () => {
            if (this.isOver) {
                this.resetGame();
                this.bird.resetBird();
                this.startGame();
            } else {
                this.bird.fly();
                this.audio.onAudioQueue(0); // flap
            }
        });
    }

    startGame() {
        this.result.hideResults();
        director.resume();
    }

    gameOver() {
        this.result.showResults();
        this.isOver = true;
        this.audio.onAudioQueue(3); // die
        director.pause();
    }

    resetGame() {
        this.result.resetScore();
        this.pipeQueue.reset();
        this.isOver = false;
        this.startGame();
    }

    passPipe() {
        this.result.addScore();
        this.audio.onAudioQueue(1); // point
    }

    createPipe() {
        this.pipeQueue.addPool();
    }

    // ⭐ Collision callback
    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        this.bird.hitSomething = true;
        this.audio.onAudioQueue(2); // hit
    }

    birdStruck() {
        if (this.bird.hitSomething === true) {
            this.gameOver();
        }
    }

    update() {
        if (!this.isOver) {
            this.birdStruck();
        }
    }
}
