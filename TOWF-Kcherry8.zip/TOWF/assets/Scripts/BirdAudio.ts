import { _decorator, Component, AudioClip, AudioSource } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('BirdAudio')
export class BirdAudio extends Component {

    @property({
        type: [AudioClip],
        tooltip: '0: flap, 1: point, 2: hit, 3: die'
    })
    public clips: AudioClip[] = [];

    @property({
        type: AudioSource,
        tooltip: 'Main audio source for all bird sounds'
    })
    public audioSource: AudioSource = null;

    /**
     * Plays the correct sound based on the index:
     * 0 = flap
     * 1 = point
     * 2 = hit
     * 3 = die
     */
    onAudioQueue(index: number) {
        if (!this.audioSource) {
            console.warn("BirdAudio: audioSource is not assigned!");
            return;
        }

        const clip = this.clips[index];
        if (!clip) {
            console.warn(`BirdAudio: No audio clip found at index ${index}`);
            return;
        }

        this.audioSource.playOneShot(clip);
    }
}
