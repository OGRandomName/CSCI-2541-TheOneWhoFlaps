System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/kench/OneDrive/Documents/Flappybirb/assets/Scripts/GameCtrl.ts at runtime.
      throw new Error(`Error: Error when fetching file C:\Users\kench\OneDrive\Documents\Flappybirb\assets\Scripts\GameCtrl.ts: Error: ENOENT: no such file or directory, open 'C:\Users\kench\OneDrive\Documents\Flappybirb\assets\Scripts\GameCtrl.ts'`);
    }
  };
});
//# sourceMappingURL=2407779ee92908d2b975cc97a333673889c35a95.js.map