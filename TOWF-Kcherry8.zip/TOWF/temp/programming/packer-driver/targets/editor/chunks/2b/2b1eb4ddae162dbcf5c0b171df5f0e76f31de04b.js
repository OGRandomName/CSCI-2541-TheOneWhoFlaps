System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/kench/OneDrive/Documents/Flappybirb/assets/Scripts/Bird.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\kench\OneDrive\Documents\Flappybirb\assets\Scripts\Bird.ts: Unexpected token (47:8)

  45 |     }
  46 |
> 47 |     this.birdAnimation.play();
     |         ^
  48 |
  49 |
  50 |`);
    }
  };
});
//# sourceMappingURL=2b1eb4ddae162dbcf5c0b171df5f0e76f31de04b.js.map