System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/kench/OneDrive/Documents/Flappybirb/assets/Scripts/Ground.ts at runtime.
      throw new Error("Error: Error when fetching file C:UserskenchOneDriveDocumentsFlappybirbassetsScriptsGround.ts: Error: ENOENT: no such file or directory, open 'C:UserskenchOneDriveDocumentsFlappybirbassetsScriptsGround.ts'");
    }
  };
});
//# sourceMappingURL=503369eeab78f00eee3ed532ae0e35f4fb306932.js.map